package luasPersegi_Panjang;

public class luasPersegi_Panjang {
    
    public static void main(String[] args) {
        
    int p = 30;
    int l = 10;
    int t = 15;
    double Luas = p * l * t ;
    
    System.out.println("panjang = " + (p));
    System.out.println("panjang = " + (l));
    System.out.println("panjang = " + (t));
    System.out.println("Luas Persegi panjang = " + (Luas));
    
    }
 
}
